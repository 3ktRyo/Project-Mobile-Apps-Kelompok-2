package com.example.makanan.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.ImageView;

import com.example.makanan.R;
import com.example.makanan.adapters.DetailedDailyAdapter;
import com.example.makanan.models.DetailedDailyModel;

import java.util.ArrayList;
import java.util.List;

public class DetailedDailyMealActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    List<DetailedDailyModel> detailedDailyModelList;
    DetailedDailyAdapter dailyAdapter;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed_daily_meal);

        String type = getIntent().getStringExtra("type");

        recyclerView = findViewById(R.id.detailed_rec);
        imageView = findViewById(R.id.detailed_img);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        detailedDailyModelList = new ArrayList<>();
        dailyAdapter = new DetailedDailyAdapter(detailedDailyModelList);
        recyclerView.setAdapter(dailyAdapter);

        if (type != null && type.equalsIgnoreCase("Sarapan")) {

            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.breakfastbubur, "Bubur Ayam", "Rating : ", "4.9", "Rp. 10.000", "10am to 11am"));
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.breakfastnasikuning, "Nasi Kuning", "Rating : ", "4.9", "Rp. 7.000", "10am to 11am"));
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.breakfastketoprak, "Ketoprak", "Rating : ", "4.9", "Rp.10.000", "10am to 11am"));
            dailyAdapter.notifyDataSetChanged();

        }


        if (type != null && type.equalsIgnoreCase("Makan Siang")) {

            imageView.setImageResource(R.drawable.lunch);
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.lunchbakso, "Bakso", "Rating", "4.9", "Rp.10.000", "10am to 11pm"));
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.lunchmieayam, "Mie Ayam", "Rating", "4.9", "Rp.12.000", "10am to 11pm"));
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.lunchayamgeprek, "Ayam Geprek", "Rating", "4.9", "Rp.15.000", "10am to 11pm"));
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.lunchgadogado, "Gado- Gado", "Rating", "4.9", "Rp. 12.000", "10am to 11pm"));
            dailyAdapter.notifyDataSetChanged();

        }

        if (type != null && type.equalsIgnoreCase("Makan Siang")) {

            imageView.setImageResource(R.drawable.lunch);
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.lunchnasitutugoncom, "Nasi Tutu Goncom", "Rating", "4.9", "Rp. 15.000", "10am to 11pm"));
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.lunchnasiliwet, "Nasi Liwet", "Rating", "4.9", "Rp. 15.000", "10am to 11pm"));
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.lunchnasipadang, "Nasi Padang", "Rating", "4.9", "Rp. 12.000", "10am to 11pm"));
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.lunchgadogado, "Gado-Gado", "Rating", "4.9", "Rp. 12.000", "10am to 11pm"));
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.lunchayamgeprek, "Ayam Geprek", "Rating", "4.9", "Rp. 15.000", "10am to 11pm"));
            dailyAdapter.notifyDataSetChanged();

        }

        if (type != null && type.equalsIgnoreCase("Makan Malam")) {

            imageView.setImageResource(R.drawable.lunch);
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.lunchnasitutugoncom, "Nasi Tutu Goncom", "Rating", "4.9", "Rp. 15.000", "10am to 11pm"));
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.lunchayamgeprek, "Ayam Geprek", "Rating", "4.9", "Rp. 15.000", "10am to 11pm"));
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.lunchbakso, "Bakso", "Rating", "4.9", "Rp. 10.000", "10am to 11pm"));
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.nasigorengseafood, "Nasi Goreng Seafood", "Rating", "4.9", "Rp. 18.000", "10am to 11pm"));
            dailyAdapter.notifyDataSetChanged();

        }

        if (type != null && type.equalsIgnoreCase("Jajanan")) {

            imageView.setImageResource(R.drawable.lunch);
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.cireng, "Cireng", "Rating", "4.9", "Rp. 5.000", "10am to 11pm"));
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.batagor, "Batagor", "Rating", "4.9", "Rp. 10.000", "10am to 11pm"));
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.lemper, "Lemper", "Rating", "4.9", "Rp. 2.000", "10am to 11pm"));
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.darlung, "Dadar Gulung", "Rating", "4.9", "Rp. 2.000", "10am to 11pm"));
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.mendoan, "Tempe  Mendoan", "Rating", "4.9", "Rp. 5.000", "10am to 11pm"));
            dailyAdapter.notifyDataSetChanged();

        }

        if (type != null && type.equalsIgnoreCase("Minuman")) {

            imageView.setImageResource(R.drawable.lunch);
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.esbuah, "Es Buah", "Rating", "4.9", "Rp. 10.000", "10am to 11pm"));
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.escincau, "Es Cincau", "Rating", "4.9", "Rp. 7.000", "10am to 11pm"));
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.esdawet, "Es dawet", "Rating", "4.9", "Rp. 10.000", "10am to 11pm"));
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.esdoger, "Es Doger", "Rating", "4.9", "Rp. 7.000", "10am to 11pm"));
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.esjeruk, "Es jeruk", "Rating", "4.9", "Rp. 7.000", "10am to 11pm"));
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.esduren, "Es duren", "Rating", "4.9", "Rp. 10.000", "10am to 11pm"));
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.esteh, "Es teh", "Rating", "4.9", "Rp. 5.000", "10am to 11pm"));
            detailedDailyModelList.add(new DetailedDailyModel(R.drawable.esteler, "Es teler", "Rating", "4.9", "Rp 10.000", "10am to 11pm"));
            dailyAdapter.notifyDataSetChanged();

        }
    }
}