package com.example.makanan.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.makanan.R;
import com.example.makanan.adapters.FeaturedAdapter;
import com.example.makanan.adapters.FeaturedVerAdapter;
import com.example.makanan.models.FeaturedModel;
import com.example.makanan.models.FeaturedVerModel;

import java.util.ArrayList;
import java.util.List;

public class SecondFragment extends Fragment {

    //////////////////////////Featured Hor RecyclerView
    List<FeaturedModel> featuredModelsList;
    RecyclerView recyclerView;
    FeaturedAdapter featuredAdapter;

    //////////////////////////Featured Hor RecyclerView
    List<FeaturedVerModel> featuredVerModelsList;
    RecyclerView recyclerView2;
    FeaturedVerAdapter featuredVerAdapter;


    public SecondFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_first, container, false);



        //////////////////////////Featured Hor RecyclerView

        recyclerView = view.findViewById(R.id.featured_hor_rec);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(),RecyclerView.HORIZONTAL,false));
        featuredModelsList = new ArrayList<>();

        featuredModelsList.add(new FeaturedModel(R.drawable.esteh,"Es Teh","Es Teh Melati"));
        featuredModelsList.add(new FeaturedModel(R.drawable.nasigorengseafood,"Nasi Goreng Seafood","Nasi Goreng + Seafood"));
        featuredModelsList.add(new FeaturedModel(R.drawable.nasiuduk,"Nasi Uduk","Nasi Uduk + telur"));



        featuredAdapter = new FeaturedAdapter(featuredModelsList);
        recyclerView.setAdapter(featuredAdapter);

        //////////////////////////Featured ver RecyclerView

        recyclerView2 = view.findViewById(R.id.featured_ver_rec);
        recyclerView2.setLayoutManager(new LinearLayoutManager(getContext(),RecyclerView.VERTICAL,false));
        featuredVerModelsList = new ArrayList<>();

        featuredVerModelsList.add(new FeaturedVerModel(R.drawable.sphagetti,"Spaghetti","Spaghetti Bolognese","4.8","10:00 - 22:00"));
        featuredVerModelsList.add(new FeaturedVerModel(R.drawable.lunchbakso,"Bakso","Bakso Urat","4.7","11:00 - 20:00"));
        featuredVerModelsList.add(new FeaturedVerModel(R.drawable.lunchgadogado,"Gado-gado","Gado- gado + Telur","4.9","10:00 - 22:00"));
        featuredVerModelsList.add(new FeaturedVerModel(R.drawable.lunchmieayam,"Mie Ayam","Mie Ayam Original","4.6","09:00 - 21:00"));
        featuredVerModelsList.add(new FeaturedVerModel(R.drawable.lunchnasiliwet,"Nasi Liwet","Liwet Ikan Teri","4.7","10:00 - 20:00"));
        featuredVerModelsList.add(new FeaturedVerModel(R.drawable.lunchnasipadang,"Nasi Padang","Nasi Padang Paket","4.5","11:00 - 20:00"));
        featuredVerModelsList.add(new FeaturedVerModel(R.drawable.lunchnasitutugoncom,"Nasi Tutug Oncom","Paket Nasi + Ayam Goreng","4.8","10:00 - 20:00"));

        featuredVerAdapter = new FeaturedVerAdapter(featuredVerModelsList);
        recyclerView2.setAdapter(featuredVerAdapter);

        return view;
    }
}