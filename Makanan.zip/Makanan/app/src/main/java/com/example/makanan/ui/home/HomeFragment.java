package com.example.makanan.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.makanan.R;
import com.example.makanan.adapters.HomeVerAdapter;
import com.example.makanan.models.HomeVerModel;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    RecyclerView homeHorizontalRec,homeVerticalRec;

    /////////////////////// vertical
    List<HomeVerModel> homeVerModelList;
    HomeVerAdapter homeVerAdapter;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_home, container, false);

        homeHorizontalRec = root.findViewById(R.id.home_hor_rec);
        homeVerticalRec = root.findViewById(R.id.home_ver_rec);

        ////////////////////Vertical RecyclerView
        homeVerModelList = new ArrayList<>();

        homeVerModelList.add(new HomeVerModel(R.drawable.ayambakar,"Ayam Bakar", "10:00 - 23:00", "4.9","Rp. 15.000" ));
        homeVerModelList.add(new HomeVerModel(R.drawable.breakfastnasikuning, "Nasi Kuning", "10:00 - 23:00", "4.9","Rp. 7.000" ));
        homeVerModelList.add(new HomeVerModel(R.drawable.breakfastketoprak, "Ketoprak", "10:00 - 23:00", "4.9","Rp. 10.000" ));
        homeVerModelList.add(new HomeVerModel(R.drawable.lunchgadogado, "Gado-Gado", "10:00 - 23:00", "4.9","Rp. 12.000" ));
        homeVerModelList.add(new HomeVerModel(R.drawable.lunchayamgeprek, "Ayam Geprek", "10:00 - 23:00", "4.9","Rp. 15.000" ));
        homeVerModelList.add(new HomeVerModel(R.drawable.nasigorengseafood, "Nasi Goreng", "10:00 - 23:00", "4.9","Rp. 18.000" ));
        homeVerModelList.add(new HomeVerModel(R.drawable.lunchbakso, "Bakso", "10:00 - 23:00", "4.9","Rp. 10.000" ));
        homeVerModelList.add(new HomeVerModel(R.drawable.breakfastbubur, "Bubur", "10:00 - 23:00", "4.9","Rp. 10.000" ));
        homeVerModelList.add(new HomeVerModel(R.drawable.nasilmk1, "Nasi Uduk", "10:00 - 23:00", "4.9","7.000" ));
        homeVerModelList.add(new HomeVerModel(R.drawable.lunchnasiliwet, "Nasi Liwet", "10:00 - 23:00", "4.9","Rp.  15.000" ));

        homeVerAdapter = new HomeVerAdapter(getActivity(),homeVerModelList);
        homeVerticalRec.setAdapter(homeVerAdapter);
        homeVerticalRec.setLayoutManager(new LinearLayoutManager(getActivity(),RecyclerView.VERTICAL,false));
        homeVerticalRec.setHasFixedSize(true);
        homeVerticalRec.setNestedScrollingEnabled(false);

        return root;
    }
}